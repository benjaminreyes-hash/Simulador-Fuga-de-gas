extends Area2D

func _ready() -> void:
	body_entered.connect(_on_body_entered)


func _on_body_entered(body: Node2D) -> void:
	if body is CharacterBody2D:
		var hud = get_tree().get_root().get_node_or_null("mapa cocina comedor/HUD")
		# Solo gana si el temporizador está corriendo actualmente
		if hud and hud.activo:
			hud.ganar()
