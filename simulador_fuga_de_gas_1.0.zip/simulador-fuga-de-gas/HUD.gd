extends CanvasLayer

# Velocidad a la que sube/baja la toxicidad (por segundo)
const FILL_RATE = 15.0
const DRAIN_RATE = 8.0

# Duración del contador en segundos (5 minutos)
const TIEMPO_TOTAL = 300.0

var toxicidad: float = 0.0
var en_zona_toxica: bool = false

var tiempo_restante: float = TIEMPO_TOTAL
var contador_activo: bool = false
var contador_terminado: bool = false

@onready var barra: ProgressBar = $Contenedor/BarraToxicidad
@onready var contenedor: Control = $Contenedor
@onready var label_contador: Label = $ContenedorContador/LabelContador
@onready var contenedor_contador: Control = $ContenedorContador

func _ready() -> void:
	contenedor.visible = false
	contenedor_contador.visible = false

func _process(delta: float) -> void:
	# --- Toxicidad ---
	if en_zona_toxica:
		toxicidad = min(toxicidad + FILL_RATE * delta, 100.0)
	else:
		toxicidad = max(toxicidad - DRAIN_RATE * delta, 0.0)

	barra.value = toxicidad
	contenedor.visible = toxicidad > 0.0

	# --- Contador ---
	if contador_activo and not contador_terminado:
		tiempo_restante = max(tiempo_restante - delta, 0.0)
		_actualizar_label()

		if tiempo_restante <= 0.0:
			contador_terminado = true
			contador_activo = false
			label_contador.text = "⏱ 00:00 — ¡Tiempo agotado!"


func _actualizar_label() -> void:
	var minutos := int(tiempo_restante) / 60
	var segundos := int(tiempo_restante) % 60
	label_contador.text = "⏱ %02d:%02d" % [minutos, segundos]


func entrar_zona_toxica() -> void:
	en_zona_toxica = true
	# Iniciar el contador solo la primera vez
	if not contador_activo and not contador_terminado:
		contador_activo = true
		contenedor_contador.visible = true
		_actualizar_label()


func salir_zona_toxica() -> void:
	en_zona_toxica = false
	# El contador sigue corriendo aunque salga de la zona
