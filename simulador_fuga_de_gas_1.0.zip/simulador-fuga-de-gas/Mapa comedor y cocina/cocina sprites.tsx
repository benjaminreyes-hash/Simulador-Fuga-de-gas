<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.2" name="cocina sprites" tilewidth="32" tileheight="32" tilecount="9" columns="3">
 <image source="cocina sprites.png" width="98" height="98"/>
</tileset>
