<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.2" name="puerta enfemreria y baños" tilewidth="32" tileheight="32" tilecount="2" columns="1">
 <image source="puerta enfemreria y baños.png" width="32" height="64"/>
</tileset>
