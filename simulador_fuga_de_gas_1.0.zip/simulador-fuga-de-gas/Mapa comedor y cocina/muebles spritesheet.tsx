<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.2" name="muebles spritesheet" tilewidth="32" tileheight="32" tilecount="4" columns="2">
 <image source="muebles spritesheet.png" width="65" height="65"/>
</tileset>
