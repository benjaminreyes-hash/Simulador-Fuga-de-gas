<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.2" name="pilar delgado" tilewidth="32" tileheight="32" tilecount="3" columns="1">
 <image source="pilar delgado.png" width="32" height="96"/>
</tileset>
