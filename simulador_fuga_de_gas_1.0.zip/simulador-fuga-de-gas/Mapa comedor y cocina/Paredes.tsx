<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.2" name="Paredes" tilewidth="32" tileheight="32" tilecount="64" columns="8">
 <image source="Paredes.png" width="256" height="256"/>
</tileset>
