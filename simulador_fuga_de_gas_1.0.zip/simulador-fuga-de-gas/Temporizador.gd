extends CanvasLayer

const TIEMPO_TOTAL := 300.0  # 5 minutos en segundos
const UMBRAL_LENTO := 150.0  # 2:30 — fase muy lenta

signal fase_lento
signal fase_muy_lento

var tiempo_restante: float = TIEMPO_TOTAL
var activo: bool = false
var terminado: bool = false
var _emitio_muy_lento: bool = false

@onready var label: Label = $ContenedorContador/LabelContador
@onready var contenedor: Control = $ContenedorContador
@onready var panel_victoria: Control = $PanelVictoria


func _ready() -> void:
	contenedor.visible = false
	panel_victoria.visible = false


func _process(delta: float) -> void:
	if not activo or terminado:
		return

	tiempo_restante -= delta

	if tiempo_restante <= 0.0:
		tiempo_restante = 0.0
		terminado = true
		activo = false
		label.text = "⏱ 00:00"
		_set_humo(false)
		return

	if not _emitio_muy_lento and tiempo_restante <= UMBRAL_LENTO:
		_emitio_muy_lento = true
		fase_muy_lento.emit()

	var m := int(tiempo_restante) / 60
	var s := int(tiempo_restante) % 60
	label.text = "⏱ %02d:%02d" % [m, s]


func iniciar() -> void:
	if not activo and not terminado:
		activo = true
		contenedor.visible = true
		fase_lento.emit()
		_set_humo(true)


func ganar() -> void:
	activo = false
	terminado = true
	contenedor.visible = false
	panel_victoria.visible = true
	_set_humo(false)


func _set_humo(encendido: bool) -> void:
	var humo = get_tree().get_root().get_node_or_null(
		"mapa cocina comedor/ZonaCocina/Humo"
	)
	if humo:
		humo.emitting = encendido
