extends CanvasLayer

const TIEMPO_TOTAL := 120.0  # 2 minutos en segundos
const UMBRAL_LENTO := 60.0   # 1:00 — fase muy lenta

# Opacidad máxima del overlay de humo en pantalla (0.0 - 1.0)
const OVERLAY_ALPHA_MAX := 0.35
# Duración de la transición de aparición/desaparición del overlay (segundos)
const OVERLAY_FADE_DURACION := 2.5

signal fase_lento
signal fase_muy_lento

var tiempo_restante: float = TIEMPO_TOTAL
var activo: bool = false
var terminado: bool = false
var _emitio_muy_lento: bool = false

@onready var label: Label = $ContenedorContador/LabelContador
@onready var contenedor: Control = $ContenedorContador
@onready var panel_victoria: Control = $PanelVictoria
@onready var panel_derrota: Control = $PanelDerrota
@onready var overlay_humo: ColorRect = $OverlayHumo


func _ready() -> void:
	contenedor.visible = false
	panel_victoria.visible = false
	panel_derrota.visible = false
	overlay_humo.modulate.a = 0.0
	overlay_humo.visible = false
	$PanelVictoria/BotonReiniciar.pressed.connect(reiniciar)
	$PanelDerrota/BotonReiniciar.pressed.connect(reiniciar)


func _process(delta: float) -> void:
	if not activo or terminado:
		return

	tiempo_restante -= delta

	if tiempo_restante <= 0.0:
		tiempo_restante = 0.0
		terminado = true
		activo = false
		label.text = "⏱ 00:00"
		_set_humo(false)
		_fade_overlay(false)
		panel_derrota.visible = true
		return

	if not _emitio_muy_lento and tiempo_restante <= UMBRAL_LENTO:
		_emitio_muy_lento = true
		fase_muy_lento.emit()

	var m := int(tiempo_restante) / 60
	var s := int(tiempo_restante) % 60
	label.text = "⏱ %02d:%02d" % [m, s]


func iniciar() -> void:
	if not activo and not terminado:
		activo = true
		contenedor.visible = true
		fase_lento.emit()
		_set_humo(true)
		_fade_overlay(true)


func ganar() -> void:
	activo = false
	terminado = true
	contenedor.visible = false
	panel_victoria.visible = true
	_set_humo(false)
	_fade_overlay(false)


func reiniciar() -> void:
	# Resetear estado del temporizador
	tiempo_restante = TIEMPO_TOTAL
	activo = false
	terminado = false
	_emitio_muy_lento = false

	# Ocultar paneles y contador
	contenedor.visible = false
	panel_victoria.visible = false
	panel_derrota.visible = false

	# Limpiar overlay
	overlay_humo.modulate.a = 0.0
	overlay_humo.visible = false

	# Apagar humo
	_set_humo(false)

	# Resetear label
	var m := int(TIEMPO_TOTAL) / 60
	var s := int(TIEMPO_TOTAL) % 60
	label.text = "⏱ %02d:%02d" % [m, s]

	# Reposicionar al jugador a su posición inicial
	# El Node2D raíz del Jugador es quien tiene la posición en la escena
	var jugador_root = get_tree().get_root().get_node_or_null("mapa cocina comedor/Jugador")
	if jugador_root:
		jugador_root.position = Vector2(314, 544)
	# El CharacterBody2D hijo es quien tiene velocity y speed del script
	var jugador = get_tree().get_root().get_node_or_null("mapa cocina comedor/Jugador/CharacterBody2D")
	if jugador:
		jugador.velocity = Vector2.ZERO
		jugador.speed = jugador.SPEED_NORMAL

	# Reiniciar el Area2D para que body_entered vuelva a dispararse
	# cuando el jugador entre de nuevo a la zona
	var zona = get_tree().get_root().get_node_or_null("mapa cocina comedor/ZonaCocina")
	if zona:
		zona.monitoring = false
		await get_tree().process_frame
		zona.monitoring = true


func _set_humo(encendido: bool) -> void:
	var humo = get_tree().get_root().get_node_or_null(
		"mapa cocina comedor/ZonaCocina/Humo"
	)
	if humo:
		humo.emitting = encendido


func _fade_overlay(aparecer: bool) -> void:
	overlay_humo.visible = true
	var tween := create_tween()
	var alpha_destino := OVERLAY_ALPHA_MAX if aparecer else 0.0
	tween.tween_property(overlay_humo, "modulate:a", alpha_destino, OVERLAY_FADE_DURACION)
	if not aparecer:
		tween.tween_callback(func(): overlay_humo.visible = false)
