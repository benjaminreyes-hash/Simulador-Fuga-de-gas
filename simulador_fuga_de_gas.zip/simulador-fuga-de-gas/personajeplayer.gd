extends CharacterBody2D

const SPEED_NORMAL  = 90.0   # velocidad base
const SPEED_LENTO   = 45.0   # al activarse el temporizador (~50%)
const SPEED_MUY_LENTO = 18.0 # al llegar a 2:30 (~20%)

var speed: float = SPEED_NORMAL

@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D


func _ready() -> void:
	# Conectar las señales del temporizador cuando el árbol esté listo
	call_deferred("_conectar_temporizador")


func _conectar_temporizador() -> void:
	var hud = get_tree().get_root().get_node_or_null("mapa cocina comedor/HUD")
	if hud:
		if not hud.fase_lento.is_connected(_on_fase_lento):
			hud.fase_lento.connect(_on_fase_lento)
		if not hud.fase_muy_lento.is_connected(_on_fase_muy_lento):
			hud.fase_muy_lento.connect(_on_fase_muy_lento)


func _on_fase_lento() -> void:
	speed = SPEED_LENTO


func _on_fase_muy_lento() -> void:
	speed = SPEED_MUY_LENTO


func _physics_process(_delta: float) -> void:
	var direction_x := Input.get_axis("ui_left", "ui_right")
	var direction_y := Input.get_axis("ui_up", "ui_down")

	velocity.x = direction_x * speed
	velocity.y = direction_y * speed

	move_and_slide()

	_update_animation(direction_x, direction_y)


func _update_animation(dir_x: float, dir_y: float) -> void:
	if dir_x == 0 and dir_y == 0:
		animated_sprite.play("idle")
	elif abs(dir_x) >= abs(dir_y):
		animated_sprite.play("walk_right")
		animated_sprite.flip_h = dir_x < 0
	else:
		animated_sprite.flip_h = false
		if dir_y > 0:
			animated_sprite.play("walk_down")
		else:
			animated_sprite.play("walk_up")
